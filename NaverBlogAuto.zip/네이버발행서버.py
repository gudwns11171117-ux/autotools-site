# -*- coding: utf-8 -*-
"""
네이버 블로그 자동발행 서버 v5.0 (Playwright - 진단기반 수정)
포트: 7777
"""
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from playwright.sync_api import sync_playwright, TimeoutError as PwTimeout
import threading, time, re, pyperclip

app = Flask(__name__)
CORS(app)

pub_status   = {"state": "idle", "msg": "대기 중"}
batch_status = {"state": "idle", "total": 0, "current": 0, "items": []}
_pub_lock    = threading.Lock()   # 단일/일괄 동시 실행 방지

def set_st(state, msg):
    pub_status['state'] = state
    pub_status['msg']   = msg
    print(f"[{state.upper()}] {msg}")


# ─────────────────────────────────────────────
#  API 엔드포인트
# ─────────────────────────────────────────────

@app.route('/')
def index():
    """앱 창용 HTML 서빙"""
    import os, sys
    if getattr(sys, 'frozen', False):
        # PyInstaller: datas는 _MEIPASS에 추출됨
        base = getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    html_path = os.path.join(base, '네이버 자동발행.html')
    try:
        with open(html_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return content, 200, {'Content-Type': 'text/html; charset=utf-8'}
    except Exception as e:
        return f'HTML 파일 오류: {e}<br>경로: {html_path}', 500

@app.route('/ping')
def ping():
    return jsonify({'ok': True})

@app.route('/status')
def get_status():
    return jsonify(pub_status)

@app.route('/reset')
def reset():
    pub_status['state'] = 'idle'
    pub_status['msg']   = '대기 중'
    return jsonify({'ok': True})

@app.route('/batch_status')
def get_batch_status():
    return jsonify(batch_status)

@app.route('/batch_reset')
def batch_reset():
    batch_status.update({'state': 'idle', 'total': 0, 'current': 0, 'items': []})
    return jsonify({'ok': True})

@app.route('/publish', methods=['POST'])
def publish():
    if pub_status['state'] == 'running' or batch_status['state'] == 'running':
        return jsonify({'ok': False, 'msg': '이미 발행 중입니다'})
    data = request.json
    threading.Thread(target=do_publish, args=(data,), daemon=True).start()
    return jsonify({'ok': True})

@app.route('/batch_publish', methods=['POST'])
def batch_publish():
    if pub_status['state'] == 'running' or batch_status['state'] == 'running':
        return jsonify({'ok': False, 'msg': '이미 발행 중입니다'})
    items = request.json
    threading.Thread(target=do_batch, args=(items,), daemon=True).start()
    return jsonify({'ok': True})


# ─────────────────────────────────────────────
#  유틸
# ─────────────────────────────────────────────

def cb_paste(page, text):
    """클립보드로 붙여넣기 (네이버 봇 감지 우회)"""
    pyperclip.copy(text)
    time.sleep(0.25)
    page.keyboard.press("Control+v")
    time.sleep(0.3)


def content_to_html(text):
    """[소제목]/[말풍선] 마커를 Naver 블로그 호환 HTML로 변환"""
    lines = text.split('\n')
    html = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        elif re.match(r'^\[소제목\]', line):
            heading = re.sub(r'^\[소제목\]\s*', '', line).strip()
            html.append(
                f'<h3 style="font-size:19px;font-weight:800;color:#222;'
                f'border-left:5px solid #6c63ff;padding-left:14px;'
                f'margin:28px 0 10px;">▶ {heading}</h3>'
            )
        elif re.match(r'^\[말풍선\]', line):
            content = re.sub(r'^\[말풍선\]\s*', '', line).strip()
            html.append(
                f'<blockquote style="background:#f0eeff;border-left:4px solid #6c63ff;'
                f'padding:14px 20px;margin:14px 0;border-radius:0 12px 12px 0;'
                f'font-size:14px;color:#444;font-style:normal;">'
                f'💬 {content}</blockquote>'
            )
        else:
            html.append(
                f'<p style="font-size:15px;line-height:1.9;color:#333;margin:8px 0;">{line}</p>'
            )
    return ''.join(html)


def dismiss_popups(page):
    """JS로 팝업/모달/도움말 패널 닫기 (Playwright text 선택자 우회)"""
    try:
        page.evaluate("""() => {
            // 도움말 패널
            const help = document.querySelector('.se-help-panel-close-button');
            if (help && help.offsetHeight > 0) help.click();
            // 모달 팝업 내 확인/닫기 버튼
            for (const b of document.querySelectorAll('button')) {
                const txt = b.innerText.trim();
                if (b.offsetHeight > 0 && (
                    txt.includes('확인') || txt === '닫기' || txt === '계속 작성'
                )) {
                    if (!b.className.includes('confirm_btn') && !b.className.includes('publish_btn')) {
                        b.click();
                    }
                }
            }
        }""")
        time.sleep(0.4)
    except: pass
    for sel in ["button[aria-label='닫기']", "button[title='닫기']", ".btn_close"]:
        try:
            for el in page.locator(sel).all():
                if el.is_visible(): el.click(); time.sleep(0.2)
        except: pass


# ─────────────────────────────────────────────
#  에디터 조작
# ─────────────────────────────────────────────

def input_title(page, title):
    """제목 입력 - 진단에서 확인된 셀렉터 사용. 입력 후 포커스 유지(Tab으로 본문 이동 준비)."""
    title_sels = [
        '[class*="se-title"]',
        '.se-title-input',
        '[class*="title_input"]',
    ]
    for sel in title_sels:
        try:
            el = page.locator(sel).first
            el.wait_for(state='visible', timeout=5000)
            el.click()
            time.sleep(0.4)
            page.keyboard.press("Control+a")
            time.sleep(0.1)
            page.keyboard.press("Delete")
            time.sleep(0.1)
            pyperclip.copy(title)
            time.sleep(0.25)
            page.keyboard.press("Control+v")
            time.sleep(0.4)
            got = el.inner_text()
            print(f"[TITLE] OK ({sel}): '{got[:30]}'")
            return True
        except: continue

    # placeholder 탐색
    for ph in ["제목을 입력해 주세요.", "제목", "Title"]:
        try:
            el = page.get_by_placeholder(ph, exact=False).first
            el.wait_for(state='visible', timeout=2000)
            el.click(); time.sleep(0.4)
            page.keyboard.press("Control+a")
            page.keyboard.press("Delete")
            pyperclip.copy(title)
            time.sleep(0.25)
            page.keyboard.press("Control+v")
            time.sleep(0.4)
            print(f"[TITLE] OK (placeholder={ph})")
            return True
        except: continue

    print("[TITLE] FAIL: 셀렉터 없음")
    return False


def paste_html_clipboard(page, html):
    """JS Clipboard API로 HTML을 클립보드에 쓰고 Ctrl+V로 붙여넣기"""
    try:
        page.evaluate("""async (h) => {
            const blob = new Blob([h], {type: 'text/html'});
            await navigator.clipboard.write([new ClipboardItem({'text/html': blob})]);
        }""", html)
        time.sleep(0.4)
        page.keyboard.press("Control+v")
        time.sleep(0.8)
        return True
    except Exception as e:
        print(f"[CLIP] HTML 클립보드 실패, 일반 텍스트로 폴백: {e}")
        # 폴백: plain text
        plain = re.sub(r'<[^>]+>', '', html)
        pyperclip.copy(plain)
        time.sleep(0.25)
        page.keyboard.press("Control+v")
        time.sleep(0.5)
        return True


def input_body(page, content):
    """본문 입력 - HTML 클립보드로 말풍선/소제목 디자인 포함 붙여넣기"""
    html = content_to_html(content)

    # 방법1: 제목 끝에서 End+Enter → 본문으로 커서 이동 후 HTML 붙여넣기
    try:
        page.keyboard.press("End")
        time.sleep(0.2)
        page.keyboard.press("Enter")
        time.sleep(0.4)
        paste_html_clipboard(page, html)
        length = page.evaluate("""() => {
            const el = document.querySelector('[class*="se-content"]');
            return el ? el.innerText.length : 0;
        }""")
        if length > 10:
            print(f"[BODY] OK (HTML 붙여넣기): {length}자")
            return True
        print(f"[BODY] Enter 방법 결과 {length}자 - 다른 방법 시도")
    except Exception as e:
        print(f"[BODY] Enter 방법 오류: {e}")

    # 방법2: Tab 키로 본문 이동
    try:
        el = page.locator('[class*="se-title"]').first
        el.click(); time.sleep(0.3)
        page.keyboard.press("End"); time.sleep(0.2)
        page.keyboard.press("Tab"); time.sleep(0.5)
        paste_html_clipboard(page, html)
        length = page.evaluate("""() => {
            const el = document.querySelector('[class*="se-content"]');
            return el ? el.innerText.length : 0;
        }""")
        if length > 10:
            print(f"[BODY] OK (Tab+HTML): {length}자")
            return True
        print(f"[BODY] Tab 방법 결과 {length}자")
    except Exception as e:
        print(f"[BODY] Tab 방법 오류: {e}")

    # 방법3: se-section 직접 클릭 후 HTML 붙여넣기
    try:
        page.evaluate("""() => {
            const content = document.querySelector('[class*="se-content"]');
            if (!content) return;
            const sections = content.querySelectorAll('[class*="se-section"]:not([class*="Title"])');
            if (sections.length > 0) sections[0].click();
            else content.click();
        }""")
        time.sleep(0.4)
        paste_html_clipboard(page, html)
        print("[BODY] OK (se-section+HTML 클릭)")
        return True
    except Exception as e:
        print(f"[BODY] FAIL: {e}")
        return False


def click_publish_btn(page):
    """
    발행 버튼 클릭
    진단 확인: class=publish_btn__m9KHH, text='발행'
    is_visible() 오류 있으므로 JS 직접 클릭 사용
    """
    # 방법1: JS 직접 클릭 (가장 안정적)
    result = page.evaluate("""() => {
        // class 기반
        let btn = document.querySelector("button[class*='publish_btn']");
        if (!btn) {
            // 텍스트 기반
            for (const b of document.querySelectorAll('button')) {
                const txt = b.innerText.trim();
                if (txt === '발행' || txt === '발행하기') { btn = b; break; }
            }
        }
        if (btn) {
            btn.scrollIntoView({block: 'center'});
            btn.click();
            return btn.className;
        }
        return null;
    }""")

    if result:
        print(f"[PUB] JS 클릭 성공: {result[:50]}")
        return True

    # 방법2: Playwright locator (scroll_into_view_if_needed 포함)
    for sel in ["button[class*='publish_btn']", "button[class*='publishBtn']"]:
        try:
            el = page.locator(sel).first
            el.scroll_into_view_if_needed(timeout=3000)
            el.click(timeout=3000)
            print(f"[PUB] Playwright 클릭 성공: {sel}")
            return True
        except: continue

    # 방법3: 텍스트
    for txt in ["발행", "발행하기"]:
        try:
            el = page.locator(f"button:text-is('{txt}')").first
            el.scroll_into_view_if_needed(timeout=2000)
            el.click(timeout=2000)
            print(f"[PUB] 텍스트 클릭: '{txt}'")
            return True
        except: continue

    print("[PUB] FAIL")
    return False


def set_schedule(page, sched_dt):
    """예약 발행 설정"""
    try:
        for sel in ["input[value='reservation']", "label[for*='reserv']", "[class*='reserv']"]:
            try:
                el = page.locator(sel).first
                if el.is_visible(timeout=1000): el.click(); time.sleep(1); break
            except: continue

        parts = sched_dt.split("T")
        date_str = parts[0]
        time_str = parts[1][:5] if len(parts) > 1 else "09:00"

        for sel in ["input[type='date']", "input[name*='date']"]:
            els = page.locator(sel).all()
            if els: els[0].fill(date_str); break

        for sel in ["input[type='time']", "input[name*='time']"]:
            els = page.locator(sel).all()
            if els: els[0].fill(time_str); break
    except Exception as e:
        print(f"[SCHED] 오류: {e}")


def confirm_publish(page):
    """최종 발행 확인 버튼 클릭"""
    # 발행 패널이 열릴 때까지 최대 5초 대기
    panel_found = False
    for _ in range(10):
        time.sleep(0.5)
        panel_found = page.evaluate("""() => {
            const sels = [
                "[class*='publish_panel']","[class*='publishLayer']",
                "[class*='layer_publish']","[class*='publish_layer']",
                "[class*='PostPublish']","[class*='post_publish']"
            ];
            return sels.some(s => !!document.querySelector(s));
        }""")
        if panel_found:
            print("[CONFIRM] 발행 패널 감지")
            time.sleep(0.3)
            break

    # JS로 발행 패널 내 버튼 클릭
    result = page.evaluate("""() => {
        const panelSels = [
            "[class*='publish_panel']","[class*='publishLayer']",
            "[class*='layer_publish']","[class*='publish_layer']",
            "[class*='PostPublish']","[class*='post_publish']"
        ];
        for (const ps of panelSels) {
            const panel = document.querySelector(ps);
            if (!panel) continue;
            // 1순위: "발행하기" 정확히 일치
            for (const b of panel.querySelectorAll('button')) {
                const txt = b.innerText.trim();
                if (b.offsetHeight > 0 && (txt === '발행하기' || txt === '게시하기')) {
                    b.scrollIntoView({block:'center'});
                    b.click();
                    return 'panel_exact:' + txt;
                }
            }
            // 2순위: class에 confirm/submit 포함
            for (const b of panel.querySelectorAll('button')) {
                const cls = b.className;
                if (b.offsetHeight > 0 && (cls.includes('confirm') || cls.includes('submit') || cls.includes('publish_now'))) {
                    b.scrollIntoView({block:'center'});
                    b.click();
                    return 'panel_cls:' + b.innerText.trim() + '|' + cls.substring(0,40);
                }
            }
        }
        // 전역 텍스트 탐색
        for (const b of document.querySelectorAll('button')) {
            const txt = b.innerText.trim();
            const cls = b.className;
            if ((txt === '발행하기' || txt === '게시하기') && b.offsetHeight > 0) {
                b.scrollIntoView({block:'center'});
                b.click();
                return 'global_text:' + txt;
            }
            if ((cls.includes('confirm') || cls.includes('submit_btn')) && b.offsetHeight > 0) {
                b.scrollIntoView({block:'center'});
                b.click();
                return 'global_cls:' + cls.substring(0,40);
            }
        }
        // 버튼 목록 디버그
        const btns = Array.from(document.querySelectorAll('button'))
            .filter(b=>b.offsetHeight>0)
            .map(b=>b.innerText.trim().substring(0,20)+'|'+b.className.substring(0,30))
            .join(' // ');
        return 'no_match:' + btns.substring(0,200);
    }""")

    if result and not result.startswith('no_match'):
        print(f"[CONFIRM] 클릭 성공: {result}")
        return True

    print(f"[CONFIRM] 패널 버튼 없음: {result}")

    # Playwright 폴백
    for txt in ["발행하기", "발행", "확인", "게시하기"]:
        try:
            el = page.locator(f"button:text-is('{txt}')").first
            el.scroll_into_view_if_needed(timeout=1500)
            el.click(timeout=1500)
            print(f"[CONFIRM] 텍스트 클릭: '{txt}'")
            return True
        except: continue

    print("[CONFIRM] 최종 실패")
    return False


# ─────────────────────────────────────────────
#  메인 발행 로직
# ─────────────────────────────────────────────

def run_playwright(data, set_status):
    """Playwright 브라우저 자동화 — 단일/일괄 공통. 예외를 그대로 raise."""
    nid      = data['id']
    npw      = data['pw']
    raw_blog = data.get('blog_id', nid) or nid
    blog_id  = raw_blog.rstrip('/').split('/')[-1]
    title    = data['title']
    content  = data['content']
    sched    = data.get('schedule_dt')

    with sync_playwright() as p:
        # ── 브라우저 실행 ──
        set_status("running", "브라우저 실행 중...")
        browser = p.chromium.launch(
            headless=False,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--start-maximized',
                '--disable-notifications',
            ]
        )
        ctx = browser.new_context(
            user_agent=(
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/120.0.0.0 Safari/537.36'
            ),
            no_viewport=True,
            permissions=["clipboard-read", "clipboard-write"],
        )
        ctx.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
            "window.chrome={runtime:{}};"
        )
        ctx.on("dialog", lambda d: d.accept())
        page = ctx.new_page()

        try:
            # ── 로그인 ──
            set_status("running", "네이버 로그인 중...")
            page.goto("https://nid.naver.com/nidlogin.login?mode=form")
            page.wait_for_load_state("domcontentloaded")
            time.sleep(2)

            page.locator("#id").click(); time.sleep(0.4)
            cb_paste(page, nid)
            page.locator("#pw").click(); time.sleep(0.4)
            cb_paste(page, npw)

            try: page.locator("#log\\.login").click()
            except:
                try: page.locator("button[type='submit']").first.click()
                except: pass

            set_status("running", "로그인 대기 중... (2단계 인증 뜨면 직접 완료, 최대 2분)")
            try:
                page.wait_for_url(
                    lambda url: "nidlogin.login" not in url,
                    timeout=120000
                )
                print(f"[LOGIN] 완료: {page.url[:60]}")
            except PwTimeout:
                raise RuntimeError("로그인 2분 초과. 아이디/비밀번호를 확인해주세요.")

            time.sleep(1)
            dismiss_popups(page)

            # ── 에디터 이동 ──
            set_status("running", "블로그 에디터 여는 중...")
            page.goto(f"https://blog.naver.com/{blog_id}/postwrite")

            set_status("running", "에디터 로딩 중... (최대 40초)")
            editor_ok = False
            for i in range(40):
                time.sleep(1)
                dismiss_popups(page)
                try:
                    for txt in ["확인", "계속 작성", "닫기", "예"]:
                        for el in page.locator(f"button:text('{txt}')").all():
                            if el.is_visible(): el.click(); time.sleep(0.4)
                except: pass
                try:
                    cnt = page.locator('[contenteditable="true"]').count()
                    if cnt > 0:
                        print(f"[EDITOR] {i+1}s: contenteditable 감지 (CE={cnt})")
                        editor_ok = True
                        break
                except: pass

            if not editor_ok:
                raise RuntimeError("에디터 로드 실패. 블로그 ID를 확인해주세요.")

            time.sleep(4)  # SE-ONE Vue 초기화 대기

            set_status("running", "팝업 처리 중...")
            for _ in range(6):
                dismiss_popups(page)
                time.sleep(0.5)

            # ── 제목 입력 ──
            set_status("running", "제목 입력 중...")
            if not input_title(page, title):
                raise RuntimeError("제목 입력 실패.")

            time.sleep(0.5)

            # ── 본문 입력 ──
            set_status("running", "본문 입력 중...")
            if not input_body(page, content):
                raise RuntimeError("본문 입력 실패.")

            time.sleep(1.5)
            dismiss_popups(page)
            time.sleep(0.5)

            # ── 발행 버튼 ──
            set_status("running", "발행 버튼 클릭 중...")
            if not click_publish_btn(page):
                raise RuntimeError("발행 버튼을 찾지 못했습니다.")

            time.sleep(1)

            # ── 예약 설정 ──
            if sched:
                set_status("running", f"예약 설정 중... ({sched})")
                set_schedule(page, sched)
                time.sleep(1)

            # ── 최종 발행 확인 ──
            set_status("running", "최종 발행 처리 중...")
            confirm_publish(page)
            time.sleep(3)

            if sched:
                set_status("done", f"예약 발행 완료! ({sched[:10]} {sched[11:16]})")
            else:
                set_status("done", "발행 완료!")

            time.sleep(5)

        finally:
            browser.close()


def do_publish(data):
    """단일 발행"""
    try:
        run_playwright(data, set_st)
    except Exception as e:
        import traceback; traceback.print_exc()
        set_st("error", f"오류: {str(e)}")


def do_batch(items):
    """일괄 발행 — 순서대로 순차 처리"""
    batch_status.update({
        'state':   'running',
        'total':   len(items),
        'current': 0,
        'items':   [{'title': it.get('title', f'항목{i+1}')[:30],
                     'state': 'pending', 'msg': '대기 중'}
                    for i, it in enumerate(items)]
    })

    for i, item in enumerate(items):
        batch_status['current'] = i + 1
        batch_status['items'][i]['state'] = 'running'

        def make_cb(idx):
            def cb(state, msg):
                batch_status['items'][idx]['msg'] = msg
                print(f"[BATCH {idx+1}/{batch_status['total']}] {msg}")
            return cb

        try:
            run_playwright(item, make_cb(i))
            batch_status['items'][i]['state'] = 'done'
            sched = item.get('schedule_dt')
            batch_status['items'][i]['msg'] = (
                f"예약 완료 ({sched[:10]} {sched[11:16]})" if sched else "발행 완료 ✓"
            )
        except Exception as e:
            import traceback; traceback.print_exc()
            batch_status['items'][i]['state'] = 'error'
            batch_status['items'][i]['msg']   = str(e)[:60]

        if i < len(items) - 1:
            time.sleep(3)   # 항목 간 잠시 대기

    batch_status['state'] = 'done'


# ─────────────────────────────────────────────
#  서버 시작
# ─────────────────────────────────────────────

if __name__ == '__main__':
    print("=" * 55)
    print("  네이버 블로그 자동발행 서버 v6.0")
    print("  주소: http://localhost:7777")
    print("  종료: Ctrl + C")
    print("=" * 55)
    app.run(host='127.0.0.1', port=7777, debug=False)
