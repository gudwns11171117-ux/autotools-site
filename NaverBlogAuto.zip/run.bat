@echo off
setlocal EnableDelayedExpansion
title NaverBlog Server
chcp 65001 >nul 2>&1

:: ════════════════════════════════════════════
::  Python 자동 탐색
:: ════════════════════════════════════════════
set "PYTHON="
py -3 --version >nul 2>&1
if not errorlevel 1 set "PYTHON=py -3"

if not defined PYTHON (
  python --version >nul 2>&1
  if not errorlevel 1 set "PYTHON=python"
)

if not defined PYTHON (
  for %%V in (313 312 311 310 39) do (
    if not defined PYTHON (
      if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
        set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
      )
    )
  )
)

if not defined PYTHON (
  echo.
  echo [ERROR] Python이 설치되어 있지 않습니다.
  echo         먼저 install.bat 을 실행해 주세요.
  echo.
  pause
  exit /b 1
)

echo  Python: %PYTHON%

:: ════════════════════════════════════════════
::  필수 패키지 자가 점검 & 자동 재설치
:: ════════════════════════════════════════════
%PYTHON% -c "import flask, flask_cors, playwright, pyperclip, requests" >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [!] 필수 패키지 누락 감지 — 자동 재설치 중...
  %PYTHON% -m pip install --upgrade pip
  %PYTHON% -m pip install flask flask-cors playwright pyperclip requests
  if errorlevel 1 (
    echo.
    echo  [ERROR] 패키지 설치 실패. install.bat 을 다시 실행해 주세요.
    pause
    exit /b 1
  )
  %PYTHON% -m playwright install chromium
)

:: ════════════════════════════════════════════
::  포트 7777 선점 프로세스 종료
:: ════════════════════════════════════════════
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":7777 " ^| findstr "LISTENING"') do (
  taskkill /F /PID %%a >nul 2>&1
)
timeout /t 1 /nobreak >nul

echo.
echo  ══════════════════════════════════════════════════════
echo   NaverBlog Auto Publisher
echo   주소 : http://localhost:7777
echo   종료 : 이 창을 닫거나 Ctrl+C
echo  ══════════════════════════════════════════════════════
echo.

:: 브라우저 오픈은 server.py 안에서 포트 바인딩 확인 후 자동 실행
%PYTHON% "%~dp0server.py"
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
  echo.
  echo  ══════════════════════════════════════════════════════
  echo  [ERROR] 서버가 비정상 종료되었습니다. (code %RC%)
  echo   해결 순서:
  echo    1) 위 에러 메시지 스크린샷을 확인하세요.
  echo    2) install.bat 을 다시 실행해 보세요.
  echo    3) 백신/방화벽이 python.exe 를 차단하지 않는지 확인.
  echo  ══════════════════════════════════════════════════════
  pause
)
endlocal
