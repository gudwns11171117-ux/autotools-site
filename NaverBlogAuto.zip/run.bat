@echo off
chcp 65001
title NaverBlog Server
echo.
echo  Starting server...
echo  Browser will open in 3 seconds.
echo  Close this window to stop the server.
echo.
py -c "import threading,webbrowser; threading.Timer(3,webbrowser.open,['http://localhost:7777']).start()"
py server.py
pause
