@echo off
chcp 65001
title NaverBlog Server
echo.
echo  Starting server...
start /min cmd /c "timeout /t 3 /nobreak > /dev/null && start http://localhost:7777"
echo  Browser will open automatically.
echo  Close this window to stop the server.
echo.
py server.py
pause
