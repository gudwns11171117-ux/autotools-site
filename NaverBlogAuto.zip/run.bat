@echo off
title NaverBlog Server

set PYTHON=C:\Users\HYS\AppData\Local\Programs\Python\Python312\python.exe

if not exist "%PYTHON%" set PYTHON=py

for /f "tokens=5" %%a in (\'netstat -ano 2^>/dev/null ^| findstr ":7777 "\') do taskkill /F /PID %%a >/dev/null 2>&1
timeout /t 1 /nobreak >nul

echo.
echo  NaverBlog Auto Publisher - http://localhost:7777
echo  Close this window to stop.
echo.

start "" "http://localhost:7777"

"%PYTHON%" "%~dp0server.py"
if errorlevel 1 (
  echo.
  echo [ERROR] Server failed.
  pause
)
