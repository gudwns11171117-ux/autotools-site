@echo off
setlocal EnableDelayedExpansion
title NaverBlog Server

:: ── Python 자동 탐색 ──
set "PYTHON="
py -3 --version >nul 2>&1
if not errorlevel 1 set "PYTHON=py -3"

if not defined PYTHON (
  python --version >nul 2>&1
  if not errorlevel 1 set "PYTHON=python"
)

if not defined PYTHON (
  for %%V in (313 312 311 310 39) do (
    if not defined PYTHON (
      if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
        set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
      )
    )
  )
)

if not defined PYTHON (
  echo.
  echo [ERROR] Python not found. Please run install.bat first.
  echo.
  pause
  exit /b 1
)

:: ── 포트 7777 점유 프로세스 종료 ──
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":7777 "') do (
  taskkill /F /PID %%a >nul 2>&1
)
timeout /t 1 /nobreak >nul

echo.
echo  NaverBlog Auto Publisher - http://localhost:7777
echo  Close this window to stop.
echo.

:: ── 서버가 뜬 뒤에 브라우저 열기 ──
start "" /B cmd /c "timeout /t 3 /nobreak >nul & start """" http://localhost:7777"

%PYTHON% "%~dp0server.py"
if errorlevel 1 (
  echo.
  echo [ERROR] Server failed to start.
  echo  - Check that install.bat completed successfully.
  echo  - If the problem persists, reinstall Python from python.org.
  pause
)
endlocal
