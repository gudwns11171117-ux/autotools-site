@echo off
setlocal EnableDelayedExpansion
title NaverBlog Server

:: ============================================
::  Find Python
:: ============================================
set "PYTHON="
py -3 --version >nul 2>&1
if not errorlevel 1 set "PYTHON=py -3"

if not defined PYTHON (
  python --version >nul 2>&1
  if not errorlevel 1 set "PYTHON=python"
)

if not defined PYTHON (
  for %%V in (313 312 311 310 39) do (
    if not defined PYTHON (
      if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
        set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
      )
    )
  )
)

if not defined PYTHON (
  echo.
  echo [ERROR] Python is not installed. Please run install.bat first.
  echo.
  pause
  exit /b 1
)

echo  Python : %PYTHON%

:: ============================================
::  Self-check required packages
:: ============================================
%PYTHON% -c "import flask, flask_cors, playwright, pyperclip, requests" >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [!] Missing packages detected - auto-reinstalling...
  %PYTHON% -m pip install --upgrade pip
  %PYTHON% -m pip install flask flask-cors playwright pyperclip requests
  if errorlevel 1 (
    echo.
    echo  [ERROR] Package install failed. Please run install.bat again.
    pause
    exit /b 1
  )
  %PYTHON% -m playwright install chromium
)

:: ============================================
::  Kill any process occupying port 7777
:: ============================================
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":7777 " ^| findstr "LISTENING"') do (
  taskkill /F /PID %%a >nul 2>&1
)
timeout /t 1 /nobreak >nul

:: Set UTF-8 for Python output right before launch
chcp 65001 >nul 2>&1
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1

echo.
echo  ==================================================
echo   NaverBlog Auto Publisher
echo   URL  : http://localhost:7777
echo   Stop : Close this window or press Ctrl+C
echo  ==================================================
echo.

:: Browser will auto-open from server.py after port binds
%PYTHON% "%~dp0server.py"
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
  echo.
  echo  ==================================================
  echo  [ERROR] Server exited with code %RC%
  echo   1^) Check the error message above.
  echo   2^) Try running install.bat again.
  echo   3^) Check if antivirus is blocking python.exe
  echo  ==================================================
  pause
)
endlocal
