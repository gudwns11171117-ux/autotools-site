import urllib.request
import subprocess
import sys
import os
import site

def patch_pip():
    """Fix pip packaging regex bug (affects Python beta versions)."""
    try:
        for sp in site.getsitepackages():
            path = os.path.join(sp, 'pip', '_vendor', 'packaging', 'version.py')
            if not os.path.exists(path):
                continue
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            patched = content.replace('?+', '?').replace('*+', '*').replace('++', '+')
            if patched != content:
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(patched)
                print("  pip patched OK")
            return
    except Exception as e:
        print(f"  patch skip: {e}")

def pip_works():
    try:
        from pip._vendor.packaging.version import Version
        Version("3.12.0")
        return True
    except Exception:
        return False

print("=" * 45)
print("  NaverBlog Auto Publisher - Setup")
print("=" * 45)
print()

print("[1/4] Checking pip...")
patch_pip()
if not pip_works():
    print("  pip broken, reinstalling...")
    urllib.request.urlretrieve('https://bootstrap.pypa.io/get-pip.py', 'get-pip.py')
    subprocess.run([sys.executable, 'get-pip.py', '--quiet'], check=True)
    os.remove('get-pip.py')
    patch_pip()
print("  pip OK")

print()
print("[2/4] Installing packages...")
subprocess.run([
    sys.executable, '-m', 'pip', 'install',
    'flask', 'flask-cors', 'playwright', 'pyperclip'
], check=True)

print()
print("[3/4] Installing Chromium (1-3 min)...")
subprocess.run([sys.executable, '-m', 'playwright', 'install', 'chromium'], check=True)

print()
print("=" * 45)
print("  Setup complete!  Run: run.bat")
print("=" * 45)
input("\nPress Enter to close...")
