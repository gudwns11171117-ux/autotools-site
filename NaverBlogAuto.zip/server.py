# -*- coding: utf-8 -*-
"""
네이버 블로그 자동발행 서버 v5.0 (Playwright - 진단기반 수정)
포트: 7777
"""
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from playwright.sync_api import sync_playwright, TimeoutError as PwTimeout
import threading, time, re, pyperclip, requests, base64, tempfile, os, subprocess

app = Flask(__name__)
CORS(app)

pub_status   = {"state": "idle", "msg": "대기 중"}
batch_status = {"state": "idle", "total": 0, "current": 0, "items": []}
_pub_lock    = threading.Lock()   # 단일/일괄 동시 실행 방지

def set_st(state, msg):
    pub_status['state'] = state
    pub_status['msg']   = msg
    print(f"[{state.upper()}] {msg}")


# ─────────────────────────────────────────────
#  API 엔드포인트
# ─────────────────────────────────────────────

@app.route('/')
def index():
    """앱 창용 HTML 서빙"""
    import os, sys
    if getattr(sys, 'frozen', False):
        # PyInstaller: datas는 _MEIPASS에 추출됨
        base = getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    html_path = os.path.join(base, '네이버 자동발행.html')
    try:
        with open(html_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return content, 200, {'Content-Type': 'text/html; charset=utf-8'}
    except Exception as e:
        return f'HTML 파일 오류: {e}<br>경로: {html_path}', 500

@app.route('/ping')
def ping():
    return jsonify({'ok': True})

@app.route('/status')
def get_status():
    return jsonify(pub_status)

@app.route('/reset')
def reset():
    pub_status['state'] = 'idle'
    pub_status['msg']   = '대기 중'
    return jsonify({'ok': True})

@app.route('/batch_status')
def get_batch_status():
    return jsonify(batch_status)

@app.route('/batch_reset')
def batch_reset():
    batch_status.update({'state': 'idle', 'total': 0, 'current': 0, 'items': []})
    return jsonify({'ok': True})

@app.route('/publish', methods=['POST'])
def publish():
    if pub_status['state'] == 'running' or batch_status['state'] == 'running':
        return jsonify({'ok': False, 'msg': '이미 발행 중입니다'})
    data = request.json
    threading.Thread(target=do_publish, args=(data,), daemon=True).start()
    return jsonify({'ok': True})

@app.route('/batch_publish', methods=['POST'])
def batch_publish():
    if pub_status['state'] == 'running' or batch_status['state'] == 'running':
        return jsonify({'ok': False, 'msg': '이미 발행 중입니다'})
    items = request.json
    threading.Thread(target=do_batch, args=(items,), daemon=True).start()
    return jsonify({'ok': True})


# ─────────────────────────────────────────────
#  유틸
# ─────────────────────────────────────────────

def cb_paste(page, text):
    """클립보드로 붙여넣기 (네이버 봇 감지 우회)"""
    pyperclip.copy(text)
    time.sleep(0.25)
    page.keyboard.press("Control+v")
    time.sleep(0.3)


# ─────────────────────────────────────────────
#  서식 스타일 사전
# ─────────────────────────────────────────────
HEADING_STYLES = {
    'purple_line': {
        'tag': 'h3',
        'style': 'font-size:18px;font-weight:800;color:#222;border-left:5px solid #6c63ff;padding:8px 0 8px 16px;margin:28px 0 10px;',
        'prefix': '▶ '
    },
    'color_box': {
        'tag': 'h3',
        'style': 'font-size:17px;font-weight:700;color:#fff;background:#6c63ff;padding:10px 20px;border-radius:10px;margin:24px 0 10px;',
        'prefix': ''
    },
    'mint_box': {
        'tag': 'h3',
        'style': 'font-size:17px;font-weight:700;color:#fff;background:#48cfad;padding:10px 20px;border-radius:10px;margin:24px 0 10px;',
        'prefix': ''
    },
    'underline': {
        'tag': 'h3',
        'style': 'font-size:19px;font-weight:800;color:#333;border-bottom:3px solid #6c63ff;padding-bottom:8px;margin:28px 0 10px;',
        'prefix': ''
    },
    'simple': {
        'tag': 'h3',
        'style': 'font-size:20px;font-weight:900;color:#111;margin:28px 0 10px;',
        'prefix': '# '
    },
}

BUBBLE_STYLES = {
    'purple': {
        'style': 'background:#f0eeff;border-left:4px solid #6c63ff;padding:14px 20px;margin:14px 0;border-radius:0 12px 12px 0;font-size:14px;color:#444;font-style:normal;',
        'icon': '💬'
    },
    'mint': {
        'style': 'background:#e8faf5;border-left:4px solid #48cfad;padding:14px 20px;margin:14px 0;border-radius:0 12px 12px 0;font-size:14px;color:#444;font-style:normal;',
        'icon': '✅'
    },
    'yellow': {
        'style': 'background:#fffbe6;border-left:4px solid #f7c948;padding:14px 20px;margin:14px 0;border-radius:0 12px 12px 0;font-size:14px;color:#444;font-style:normal;',
        'icon': '💡'
    },
    'pink': {
        'style': 'background:#fff0f4;border-left:4px solid #ff6b9d;padding:14px 20px;margin:14px 0;border-radius:0 12px 12px 0;font-size:14px;color:#444;font-style:normal;',
        'icon': '🌸'
    },
    'gray': {
        'style': 'background:#f5f5f5;border-left:4px solid #999;padding:14px 20px;margin:14px 0;border-radius:0 12px 12px 0;font-size:14px;color:#555;font-style:normal;',
        'icon': '📌'
    },
}


def content_to_html(text, heading_style='purple_line', bubble_style='purple'):
    """[소제목]/[말풍선] 마커를 선택된 서식으로 HTML 변환"""
    hs = HEADING_STYLES.get(heading_style, HEADING_STYLES['purple_line'])
    bs = BUBBLE_STYLES.get(bubble_style, BUBBLE_STYLES['purple'])

    lines = text.split('\n')
    html = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        elif re.match(r'^\[소제목\]', line):
            heading = re.sub(r'^\[소제목\]\s*', '', line).strip()
            html.append(
                f'<{hs["tag"]} style="{hs["style"]}">'
                f'{hs["prefix"]}{heading}'
                f'</{hs["tag"]}>'
            )
        elif re.match(r'^\[말풍선\]', line):
            content_text = re.sub(r'^\[말풍선\]\s*', '', line).strip()
            html.append(
                f'<blockquote style="{bs["style"]}">'
                f'{bs["icon"]} {content_text}</blockquote>'
            )
        else:
            html.append(
                f'<p style="font-size:15px;line-height:1.9;color:#333;margin:8px 0;">{line}</p>'
            )
    return ''.join(html)


def dismiss_popups(page):
    """JS로 팝업/모달/도움말 패널 닫기"""
    try:
        page.evaluate("""() => {
            // 1. 도움말 패널 닫기 (다양한 셀렉터 시도, offsetHeight 조건 제거)
            const helpSels = [
                '.se-help-panel-close-button',
                '[class*="help_panel"] button[class*="close"]',
                '[class*="helpPanel"] button[class*="close"]',
                '[class*="se-help"] button[class*="close"]',
                'button[aria-label="도움말 닫기"]',
            ];
            for (const sel of helpSels) {
                const help = document.querySelector(sel);
                if (help) { help.click(); break; }
            }

            // 2. 임시저장 불러오기 팝업 - '아니오' 우선 클릭
            for (const b of document.querySelectorAll('button')) {
                const txt = b.innerText.trim();
                if (b.offsetHeight > 0 && txt === '아니오') {
                    if (!b.className.includes('publish_btn')) { b.click(); return; }
                }
            }

            // 3. 일반 팝업 처리 (확인/계속 작성)
            for (const b of document.querySelectorAll('button')) {
                const txt = b.innerText.trim();
                if (b.offsetHeight > 0 && (txt.includes('확인') || txt === '닫기' || txt === '계속 작성')) {
                    if (!b.className.includes('confirm_btn') && !b.className.includes('publish_btn')) {
                        b.click();
                    }
                }
            }
        }""")
        time.sleep(0.3)
    except: pass
    for sel in ["button[aria-label='닫기']", "button[title='닫기']", ".btn_close"]:
        try:
            for el in page.locator(sel).all():
                if el.is_visible(): el.click(); time.sleep(0.15)
        except: pass


# ─────────────────────────────────────────────
#  에디터 조작
# ─────────────────────────────────────────────

def input_title(page, title):
    """제목 입력 - 진단에서 확인된 셀렉터 사용. 입력 후 포커스 유지(Tab으로 본문 이동 준비)."""
    title_sels = [
        '[class*="se-title"]',
        '.se-title-input',
        '[class*="title_input"]',
    ]
    for sel in title_sels:
        try:
            el = page.locator(sel).first
            el.wait_for(state='visible', timeout=5000)
            el.click()
            time.sleep(0.4)
            page.keyboard.press("Control+a")
            time.sleep(0.1)
            page.keyboard.press("Delete")
            time.sleep(0.1)
            pyperclip.copy(title)
            time.sleep(0.25)
            page.keyboard.press("Control+v")
            time.sleep(0.4)
            got = el.inner_text()
            print(f"[TITLE] OK ({sel}): '{got[:30]}'")
            return True
        except: continue

    # placeholder 탐색
    for ph in ["제목을 입력해 주세요.", "제목", "Title"]:
        try:
            el = page.get_by_placeholder(ph, exact=False).first
            el.wait_for(state='visible', timeout=2000)
            el.click(); time.sleep(0.4)
            page.keyboard.press("Control+a")
            page.keyboard.press("Delete")
            pyperclip.copy(title)
            time.sleep(0.25)
            page.keyboard.press("Control+v")
            time.sleep(0.4)
            print(f"[TITLE] OK (placeholder={ph})")
            return True
        except: continue

    print("[TITLE] FAIL: 셀렉터 없음")
    return False


def paste_html_clipboard(page, html):
    """JS Clipboard API로 HTML을 클립보드에 쓰고 Ctrl+V로 붙여넣기"""
    try:
        page.evaluate("""async (h) => {
            const blob = new Blob([h], {type: 'text/html'});
            await navigator.clipboard.write([new ClipboardItem({'text/html': blob})]);
        }""", html)
        time.sleep(0.4)
        page.keyboard.press("Control+v")
        time.sleep(0.8)
        return True
    except Exception as e:
        print(f"[CLIP] HTML 클립보드 실패, 일반 텍스트로 폴백: {e}")
        # 폴백: plain text
        plain = re.sub(r'<[^>]+>', '', html)
        pyperclip.copy(plain)
        time.sleep(0.25)
        page.keyboard.press("Control+v")
        time.sleep(0.5)
        return True


# ─────────────────────────────────────────────
#  이미지 처리
# ─────────────────────────────────────────────

def parse_api_keys(api_key_input):
    """API 키 문자열(줄바꿈/쉼표 구분)을 리스트로 변환"""
    if isinstance(api_key_input, list):
        return [k.strip() for k in api_key_input if k.strip()]
    return [k.strip() for k in api_key_input.replace(',', '\n').split('\n') if k.strip()]


def generate_image(api_key, prompt):
    """Gemini Imagen 3으로 이미지 생성 → bytes 반환 (멀티키 지원)"""
    keys = parse_api_keys(api_key)
    if not keys:
        raise RuntimeError("이미지 생성 실패: API 키 없음")

    url = "https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict"
    body = {
        "instances": [{"prompt": f"블로그 삽화, 밝고 깔끔한 일러스트, 텍스트 없음, 주제: {prompt}"}],
        "parameters": {"sampleCount": 1, "aspectRatio": "16:9"}
    }
    last_err = None
    for i, key in enumerate(keys):
        try:
            resp = requests.post(url, params={"key": key}, json=body, timeout=60)
            if resp.status_code == 429:
                print(f"[IMG] 키 {i+1}/{len(keys)} QUOTA 초과, 다음 키 시도")
                last_err = RuntimeError("이미지 API 사용량 초과")
                continue
            data = resp.json()
            if "predictions" in data and data["predictions"]:
                b64 = data["predictions"][0].get("bytesBase64Encoded", "")
                if b64:
                    return base64.b64decode(b64)
            last_err = RuntimeError(f"이미지 생성 실패: {data.get('error', {}).get('message', str(data)[:80])}")
        except requests.exceptions.Timeout:
            last_err = RuntimeError("이미지 생성 타임아웃")
            continue
        except Exception as e:
            last_err = RuntimeError(str(e))
            continue
    raise last_err or RuntimeError("이미지 생성 실패: 사용 가능한 API 키 없음")


def image_bytes_to_clipboard(img_bytes):
    """이미지 bytes를 Windows 클립보드에 복사 (PowerShell 사용, 추가 패키지 불필요)"""
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
            tmp.write(img_bytes)
            tmp_path = tmp.name
        ps = f"""
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Image]::FromFile('{tmp_path.replace(chr(92), '/')}')
[System.Windows.Forms.Clipboard]::SetImage($img)
$img.Dispose()
"""
        r = subprocess.run(['powershell', '-NoProfile', '-Command', ps],
                           capture_output=True, timeout=15)
        ok = r.returncode == 0
        if not ok:
            print(f"[IMG] PS 오류: {r.stderr.decode('utf-8','replace')[:80]}")
        return ok
    except Exception as e:
        print(f"[IMG] 클립보드 예외: {e}")
        return False
    finally:
        if tmp_path:
            try: os.unlink(tmp_path)
            except: pass


def save_temp_image(img_bytes):
    """bytes → 임시 파일로 저장, 경로 반환"""
    tmp = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
    tmp.write(img_bytes)
    tmp.close()
    return tmp.name


def insert_image_to_editor(page, img_bytes):
    """이미지를 클립보드 경유로 SE-ONE 에디터에 삽입"""
    if not image_bytes_to_clipboard(img_bytes):
        return False
    time.sleep(0.4)
    page.keyboard.press("Control+v")
    time.sleep(3)   # 네이버 CDN 업로드 대기
    page.keyboard.press("End")
    time.sleep(0.3)
    return True


def parse_sections(content):
    """콘텐츠를 소제목/말풍선/본문 섹션으로 분리"""
    sections = []
    current_body = []

    for line in content.split('\n'):
        s = line.strip()
        if re.match(r'^\[소제목\]', s):
            if current_body:
                t = '\n'.join(current_body).strip()
                if t: sections.append({'type': 'body', 'text': t})
                current_body = []
            sections.append({'type': 'heading',
                             'text': re.sub(r'^\[소제목\]\s*', '', s).strip()})
        elif re.match(r'^\[말풍선\]', s):
            if current_body:
                t = '\n'.join(current_body).strip()
                if t: sections.append({'type': 'body', 'text': t})
                current_body = []
            sections.append({'type': 'bubble',
                             'text': re.sub(r'^\[말풍선\]\s*', '', s).strip()})
        else:
            if s: current_body.append(s)

    if current_body:
        t = '\n'.join(current_body).strip()
        if t: sections.append({'type': 'body', 'text': t})

    return sections


def input_body(page, content, heading_style='purple_line', bubble_style='purple'):
    """본문 입력 - HTML 클립보드로 말풍선/소제목 디자인 포함 붙여넣기"""
    html = content_to_html(content, heading_style, bubble_style)

    # 방법1: 제목 끝에서 End+Enter → 본문으로 커서 이동 후 HTML 붙여넣기
    try:
        page.keyboard.press("End")
        time.sleep(0.2)
        page.keyboard.press("Enter")
        time.sleep(0.4)
        paste_html_clipboard(page, html)
        length = page.evaluate("""() => {
            const el = document.querySelector('[class*="se-content"]');
            return el ? el.innerText.length : 0;
        }""")
        if length > 10:
            print(f"[BODY] OK (HTML 붙여넣기): {length}자")
            return True
        print(f"[BODY] Enter 방법 결과 {length}자 - 다른 방법 시도")
    except Exception as e:
        print(f"[BODY] Enter 방법 오류: {e}")

    # 방법2: Tab 키로 본문 이동
    try:
        el = page.locator('[class*="se-title"]').first
        el.click(); time.sleep(0.3)
        page.keyboard.press("End"); time.sleep(0.2)
        page.keyboard.press("Tab"); time.sleep(0.5)
        paste_html_clipboard(page, html)
        length = page.evaluate("""() => {
            const el = document.querySelector('[class*="se-content"]');
            return el ? el.innerText.length : 0;
        }""")
        if length > 10:
            print(f"[BODY] OK (Tab+HTML): {length}자")
            return True
        print(f"[BODY] Tab 방법 결과 {length}자")
    except Exception as e:
        print(f"[BODY] Tab 방법 오류: {e}")

    # 방법3: se-section 직접 클릭 후 HTML 붙여넣기
    try:
        page.evaluate("""() => {
            const content = document.querySelector('[class*="se-content"]');
            if (!content) return;
            const sections = content.querySelectorAll('[class*="se-section"]:not([class*="Title"])');
            if (sections.length > 0) sections[0].click();
            else content.click();
        }""")
        time.sleep(0.4)
        paste_html_clipboard(page, html)
        print("[BODY] OK (se-section+HTML 클릭)")
        return True
    except Exception as e:
        print(f"[BODY] FAIL: {e}")
        return False


def input_body_with_images(page, content, api_key, user_photos, set_status, heading_style='purple_line', bubble_style='purple'):
    """섹션별 본문 입력 — AI 이미지 + 현장 사진 삽입 포함"""
    hs = HEADING_STYLES.get(heading_style, HEADING_STYLES['purple_line'])
    bs = BUBBLE_STYLES.get(bubble_style, BUBBLE_STYLES['purple'])
    sections = parse_sections(content)

    # heading 인덱스 목록 (현장 사진 위치 매핑용)
    heading_sections = [i for i, s in enumerate(sections) if s['type'] == 'heading']

    # 커서 본문으로 이동
    try:
        page.keyboard.press("End")
        time.sleep(0.2)
        page.keyboard.press("Enter")
        time.sleep(0.4)
    except: pass

    heading_count = 0

    for sec in sections:
        stype = sec['type']
        stext = sec['text']

        if stype == 'heading':
            html = (
                f'<{hs["tag"]} style="{hs["style"]}">'
                f'{hs["prefix"]}{stext}'
                f'</{hs["tag"]}>'
            )
            paste_html_clipboard(page, html)
            time.sleep(0.3)

            # AI 이미지 생성
            if api_key:
                try:
                    set_status("running", f"AI 이미지 생성 중: {stext[:20]}...")
                    img_bytes = generate_image(api_key, stext)
                    if insert_image_to_editor(page, img_bytes):
                        print(f"[IMG] AI 이미지 삽입: {stext[:30]}")
                    else:
                        print(f"[IMG] AI 이미지 삽입 실패 (건너뜀)")
                except Exception as e:
                    print(f"[IMG] AI 이미지 오류 (건너뜀): {e}")

            # 현장 사진 삽입 (이 소제목 다음에 오는 것들)
            for photo in user_photos:
                if photo.get('heading_idx') == heading_count:
                    try:
                        img_bytes = base64.b64decode(photo['base64'])
                        desc = photo.get('description', '')
                        if desc:
                            desc_html = (
                                f'<p style="font-size:13px;color:#888;text-align:center;'
                                f'margin:4px 0 16px;">📷 {desc}</p>'
                            )
                        set_status("running", f"현장 사진 삽입 중... ({desc[:15]})")
                        if insert_image_to_editor(page, img_bytes):
                            print(f"[IMG] 현장 사진 삽입: {desc[:30]}")
                            if desc:
                                paste_html_clipboard(page, desc_html)
                                time.sleep(0.3)
                    except Exception as e:
                        print(f"[IMG] 현장 사진 오류: {e}")

            heading_count += 1

        elif stype == 'bubble':
            html = (
                f'<blockquote style="{bs["style"]}">'
                f'{bs["icon"]} {stext}</blockquote>'
            )
            paste_html_clipboard(page, html)
            time.sleep(0.3)

        else:  # body
            lines = [l for l in stext.split('\n') if l.strip()]
            body_html = ''.join(
                f'<p style="font-size:15px;line-height:1.9;color:#333;margin:8px 0;">{l}</p>'
                for l in lines
            )
            paste_html_clipboard(page, body_html)
            time.sleep(0.3)

    return True


def click_publish_btn(page):
    """발행 버튼 클릭 - class=publish_btn 우선, 텍스트 폴백"""
    result = page.evaluate("""() => {
        // class 기반 (publish_btn 포함, 단 confirm_btn·예약 관련 제외)
        let btn = null;
        for (const b of document.querySelectorAll("button[class*='publish_btn']")) {
            const txt = b.innerText.trim();
            if (!b.className.includes('confirm_btn') && !txt.includes('예약')) {
                btn = b; break;
            }
        }
        if (!btn) {
            for (const b of document.querySelectorAll('button')) {
                const txt = b.innerText.trim();
                if ((txt === '발행' || txt === '발행하기') && !txt.includes('예약')) { btn = b; break; }
            }
        }
        if (btn) {
            btn.scrollIntoView({block: 'center'});
            btn.click();
            return btn.className;
        }
        return null;
    }""")
    if result:
        print(f"[PUB] JS 클릭 성공: {result[:50]}")
        return True

    for sel in ["button[class*='publish_btn']", "button[class*='publishBtn']"]:
        try:
            el = page.locator(sel).first
            el.scroll_into_view_if_needed(timeout=3000)
            el.click(timeout=3000)
            return True
        except: continue

    for txt in ["발행", "발행하기"]:
        try:
            el = page.locator(f"button:text-is('{txt}')").first
            el.scroll_into_view_if_needed(timeout=2000)
            el.click(timeout=2000)
            return True
        except: continue

    print("[PUB] FAIL")
    return False


def set_schedule(page, sched_dt):
    """예약 발행 설정 — React nativeInputValueSetter 방식"""
    try:
        parts    = sched_dt.split("T")
        date_str = parts[0]
        time_str = parts[1][:5] if len(parts) > 1 else "09:00"
        year, month, day = date_str.split("-")
        hour, minute     = time_str.split(":")
        hour_int   = int(hour)
        minute_int = int(minute)

        # ── Step 1: 예약 라디오 클릭 ──
        r1 = 'not_found'
        for _attempt in range(10):
            r1 = page.evaluate("""() => {
                const YEYAK = ['예약','예약 발행','예약발행'];
                for (const el of document.querySelectorAll('label')) {
                    const txt = el.innerText.trim();
                    if (el.offsetParent !== null && YEYAK.includes(txt)) {
                        const inp = document.getElementById(el.htmlFor);
                        if (inp) inp.click();
                        el.click();
                        return 'label:' + txt;
                    }
                }
                for (const el of document.querySelectorAll('[role="radio"],[role="tab"]')) {
                    const txt = el.innerText.trim();
                    if (el.offsetParent !== null && YEYAK.includes(txt)) {
                        el.click(); return 'role:' + txt;
                    }
                }
                for (const sel of [
                    "input[value='reservation']","input[value='reserve']",
                    "input[value='RESERVATION']","input[id*='reserv']","input[name*='reserv']"
                ]) {
                    const el = document.querySelector(sel);
                    if (el && el.offsetParent !== null) { el.click(); return 'input:'+sel; }
                }
                return 'not_found';
            }""")
            if r1 != 'not_found':
                break
            time.sleep(0.5)
        print(f"[SCHED] 예약 클릭: {r1}")
        time.sleep(2)

        # ── Step 2: 날짜 설정 ──
        hour_padded = str(hour_int).zfill(2)
        min_rounded = (minute_int // 10) * 10
        min_padded  = str(min_rounded).zfill(2)

        import re as _re
        try:
            page.locator('[class*="input_date"]').first.click(timeout=3000)
            time.sleep(0.6)

            target_y, target_m, target_d = int(year), int(month), int(day)

            def read_cal_ym():
                txt = page.evaluate("""() => {
                    for (const el of document.querySelectorAll('*')) {
                        const t = (el.textContent||'').trim();
                        if (/\\d{4}년/.test(t) && /\\d{1,2}월/.test(t) && t.length < 30) return t;
                    }
                    return '';
                }""")
                m = _re.search(r'(\d{4})년\s*(\d{1,2})월', txt)
                return (int(m.group(1)), int(m.group(2))) if m else (0, 0)

            cy2, cm2 = read_cal_ym()
            if cy2 == 0:
                print("[SCHED] 달력 헤더 인식 실패, 날짜 스킵")
            else:
                month_diff = (target_y - cy2) * 12 + (target_m - cm2)
                for _nav in range(abs(month_diff)):
                    go_next = month_diff > 0
                    page.evaluate("""(goNext) => {
                        let hdrEl = null;
                        for (const el of document.querySelectorAll('*')) {
                            const t = (el.textContent||'').trim();
                            if (/\\d{4}년/.test(t) && /\\d{1,2}월/.test(t) && t.length < 30) {
                                hdrEl = el; break;
                            }
                        }
                        if (!hdrEl) return;
                        const hdrRect = hdrEl.getBoundingClientRect();
                        let best = null, bestX = goNext ? -Infinity : Infinity;
                        for (const btn of document.querySelectorAll('button')) {
                            const r = btn.getBoundingClientRect();
                            if (r.width <= 0 || r.height <= 0) continue;
                            const cy = r.top + r.height/2;
                            const hy = hdrRect.top + hdrRect.height/2;
                            if (Math.abs(cy - hy) > 30) continue;
                            if (goNext && r.left > bestX) { best = btn; bestX = r.left; }
                            if (!goNext && r.left < bestX) { best = btn; bestX = r.left; }
                        }
                        if (best) best.click();
                    }""", go_next)
                    time.sleep(0.4)

            date_coords = page.evaluate("""(args) => {
                const target = String(args.d);
                let calCont = null;
                for (const el of document.querySelectorAll('*')) {
                    const t = (el.textContent||'').trim();
                    if (/\\d{4}년/.test(t) && /\\d{1,2}월/.test(t) && t.length < 30) {
                        let node = el.parentElement;
                        for (let i = 0; i < 6; i++) {
                            if (!node) break;
                            if (node.querySelectorAll('button').length >= 28) { calCont = node; break; }
                            node = node.parentElement;
                        }
                        if (calCont) break;
                    }
                }
                if (!calCont) return {err: 'no_cal'};
                for (const el of calCont.querySelectorAll('button, td, [role="gridcell"]')) {
                    if (el.textContent.trim() !== target) continue;
                    el.scrollIntoView({block:'center', behavior:'instant'});
                    const r = el.getBoundingClientRect();
                    if (r.width > 0 && r.height > 0)
                        return {x: r.left + r.width/2, y: r.top + r.height/2};
                }
                return {err: 'not_found'};
            }""", {"d": target_d})

            if date_coords and 'x' in date_coords:
                page.mouse.click(date_coords['x'], date_coords['y'])
            time.sleep(1.0)
            page.evaluate("""() => {
                const hourEl = document.querySelector('[class*="hour__"]');
                if (hourEl) hourEl.scrollIntoView({block:'center', behavior:'instant'});
            }""")
            time.sleep(0.5)
        except Exception as _e:
            print(f"[SCHED] 날짜 설정 실패: {_e}")

        # ── Step 3: 시·분 키보드 입력 ──
        def type_into_picker(picker_sel, value, label):
            try:
                el = page.locator(picker_sel).first
                el.scroll_into_view_if_needed(timeout=2000)
                el.click(timeout=3000)
                time.sleep(0.3)
                page.keyboard.press("Control+a")
                time.sleep(0.1)
                page.keyboard.type(value)
                time.sleep(0.2)
                page.keyboard.press("Enter")
                time.sleep(0.3)
                print(f"[SCHED] {label} 입력: {value}")
            except Exception as e:
                print(f"[SCHED] {label} 입력 실패: {e}")

        type_into_picker('[class*="hour__"] input, [class*="hour__"] select, [class*="hour__"]', hour_padded, "시")
        time.sleep(0.3)
        type_into_picker('[class*="minute__"] input, [class*="minute__"] select, [class*="minute__"]', min_padded, "분")
        time.sleep(0.3)
        print(f"[SCHED] 완료: {year}.{month}.{day} {hour_padded}:{min_padded}")

    except Exception as e:
        print(f"[SCHED] 오류: {e}")


def confirm_publish(page):
    """최종 발행 확인 버튼 클릭"""
    # 발행 패널이 열릴 때까지 최대 5초 대기
    panel_found = False
    for _ in range(10):
        time.sleep(0.5)
        panel_found = page.evaluate("""() => {
            const sels = [
                "[class*='publish_panel']","[class*='publishLayer']",
                "[class*='layer_publish']","[class*='publish_layer']",
                "[class*='PostPublish']","[class*='post_publish']"
            ];
            return sels.some(s => !!document.querySelector(s));
        }""")
        if panel_found:
            print("[CONFIRM] 발행 패널 감지")
            time.sleep(0.3)
            break

    # JS로 발행 패널 내 버튼 클릭
    result = page.evaluate("""() => {
        const panelSels = [
            "[class*='publish_panel']","[class*='publishLayer']",
            "[class*='layer_publish']","[class*='publish_layer']",
            "[class*='PostPublish']","[class*='post_publish']"
        ];
        for (const ps of panelSels) {
            const panel = document.querySelector(ps);
            if (!panel) continue;
            // 1순위: "발행하기" 정확히 일치
            for (const b of panel.querySelectorAll('button')) {
                const txt = b.innerText.trim();
                if (b.offsetHeight > 0 && (txt === '발행하기' || txt === '게시하기')) {
                    b.scrollIntoView({block:'center'});
                    b.click();
                    return 'panel_exact:' + txt;
                }
            }
            // 2순위: class에 confirm/submit 포함
            for (const b of panel.querySelectorAll('button')) {
                const cls = b.className;
                if (b.offsetHeight > 0 && (cls.includes('confirm') || cls.includes('submit') || cls.includes('publish_now'))) {
                    b.scrollIntoView({block:'center'});
                    b.click();
                    return 'panel_cls:' + b.innerText.trim() + '|' + cls.substring(0,40);
                }
            }
        }
        // 전역 텍스트 탐색
        for (const b of document.querySelectorAll('button')) {
            const txt = b.innerText.trim();
            const cls = b.className;
            if ((txt === '발행하기' || txt === '게시하기') && b.offsetHeight > 0) {
                b.scrollIntoView({block:'center'});
                b.click();
                return 'global_text:' + txt;
            }
            if ((cls.includes('confirm') || cls.includes('submit_btn')) && b.offsetHeight > 0) {
                b.scrollIntoView({block:'center'});
                b.click();
                return 'global_cls:' + cls.substring(0,40);
            }
        }
        // 버튼 목록 디버그
        const btns = Array.from(document.querySelectorAll('button'))
            .filter(b=>b.offsetHeight>0)
            .map(b=>b.innerText.trim().substring(0,20)+'|'+b.className.substring(0,30))
            .join(' // ');
        return 'no_match:' + btns.substring(0,200);
    }""")

    if result and not result.startswith('no_match'):
        print(f"[CONFIRM] 클릭 성공: {result}")
        return True

    print(f"[CONFIRM] 패널 버튼 없음: {result}")

    # Playwright 폴백 — 패널 범위로 제한
    panel_sels = [
        "[class*='publish_panel']", "[class*='publishLayer']",
        "[class*='layer_publish']", "[class*='PostPublish']",
    ]
    for ps in panel_sels:
        for txt in ["발행하기", "발행", "게시하기", "예약 발행하기"]:
            try:
                el = page.locator(f"{ps} button:text-is('{txt}')").first
                el.scroll_into_view_if_needed(timeout=1500)
                el.click(timeout=1500)
                print(f"[CONFIRM] 패널+텍스트 클릭: '{txt}'")
                return True
            except: continue

    for txt in ["발행하기", "게시하기"]:
        try:
            el = page.locator(f"button:text('{txt}')").first
            el.scroll_into_view_if_needed(timeout=1500)
            el.click(timeout=1500)
            print(f"[CONFIRM] 전역 텍스트 클릭: '{txt}'")
            return True
        except: continue

    print("[CONFIRM] 최종 실패")
    return False


# ─────────────────────────────────────────────
#  메인 발행 로직
# ─────────────────────────────────────────────

def run_playwright(data, set_status):
    """Playwright 브라우저 자동화 — 단일/일괄 공통. 예외를 그대로 raise."""
    nid        = data['id']
    npw        = data['pw']
    raw_blog   = data.get('blog_id', nid) or nid
    blog_id    = raw_blog.rstrip('/').split('/')[-1]
    title      = data['title']
    content    = data['content']
    sched      = data.get('schedule_dt')
    heading_style = data.get('heading_style', 'purple_line')
    bubble_style  = data.get('bubble_style', 'purple')
    use_image  = data.get('use_image', False)
    api_key    = data.get('api_key', '')
    user_photos= data.get('user_photos', [])  # [{base64, description, heading_idx}]

    with sync_playwright() as p:
        # ── 브라우저 실행 ──
        set_status("running", "브라우저 실행 중...")
        browser = p.chromium.launch(
            headless=False,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--start-maximized',
                '--disable-notifications',
            ]
        )
        ctx = browser.new_context(
            user_agent=(
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/120.0.0.0 Safari/537.36'
            ),
            no_viewport=True,
            permissions=["clipboard-read", "clipboard-write"],
        )
        ctx.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
            "window.chrome={runtime:{}};"
        )
        ctx.on("dialog", lambda d: d.accept())
        page = ctx.new_page()

        try:
            # ── 로그인 ──
            set_status("running", "네이버 로그인 중...")
            page.goto("https://nid.naver.com/nidlogin.login?mode=form")
            page.wait_for_load_state("domcontentloaded")
            time.sleep(2)

            page.locator("#id").click(); time.sleep(0.4)
            cb_paste(page, nid)
            page.locator("#pw").click(); time.sleep(0.4)
            cb_paste(page, npw)

            try: page.locator("#log\\.login").click()
            except:
                try: page.locator("button[type='submit']").first.click()
                except: pass

            set_status("running", "로그인 대기 중... (2단계 인증 뜨면 직접 완료, 최대 2분)")
            try:
                page.wait_for_url(
                    lambda url: "nidlogin.login" not in url,
                    timeout=120000
                )
                print(f"[LOGIN] 완료: {page.url[:60]}")
            except PwTimeout:
                raise RuntimeError("로그인 2분 초과. 아이디/비밀번호를 확인해주세요.")

            time.sleep(1)
            dismiss_popups(page)

            # ── 에디터 이동 ──
            set_status("running", "블로그 에디터 여는 중...")
            page.goto(f"https://blog.naver.com/{blog_id}/postwrite")

            set_status("running", "에디터 로딩 중... (최대 40초)")
            editor_ok = False
            for i in range(40):
                time.sleep(1)
                dismiss_popups(page)
                try:
                    # 임시저장 불러오기 팝업 - 아니오 우선
                    for txt in ["아니오", "확인", "계속 작성", "닫기"]:
                        for el in page.locator(f"button:text('{txt}')").all():
                            if el.is_visible(): el.click(); time.sleep(0.3)
                except: pass
                try:
                    cnt = page.locator('[contenteditable="true"]').count()
                    if cnt > 0:
                        print(f"[EDITOR] {i+1}s: contenteditable 감지 (CE={cnt})")
                        editor_ok = True
                        break
                except: pass

            if not editor_ok:
                raise RuntimeError("에디터 로드 실패. 블로그 ID를 확인해주세요.")

            time.sleep(4)  # SE-ONE Vue 초기화 대기

            # ── 1차 팝업 처리 (본문 입력 전) — 도움말 패널 포함 ──
            set_status("running", "팝업 처리 중...")
            for _ in range(5):
                dismiss_popups(page)
                # 도움말 닫기 Playwright 폴백
                for sel in ['.se-help-panel-close-button',
                             '[class*="help_panel"] button',
                             '[class*="helpPanel"] button']:
                    try:
                        for el in page.locator(sel).all():
                            if el.is_visible(): el.click(); time.sleep(0.2)
                    except: pass
                time.sleep(0.4)

            # ── 제목 입력 ──
            set_status("running", "제목 입력 중...")
            if not input_title(page, title):
                raise RuntimeError("제목 입력 실패.")

            time.sleep(0.5)

            # ── 본문 입력 (이미지 옵션 포함) ──
            img_label = " + AI 이미지" if use_image else ""
            user_label = f" + 현장사진 {len(user_photos)}장" if user_photos else ""
            set_status("running", f"본문 입력 중...{img_label}{user_label}")

            if use_image or user_photos:
                # 섹션별 삽입 (이미지 포함)
                ok = input_body_with_images(
                    page, content,
                    api_key if use_image else None,
                    user_photos,
                    set_status,
                    heading_style, bubble_style
                )
            else:
                ok = input_body(page, content, heading_style, bubble_style)

            if not ok:
                raise RuntimeError("본문 입력 실패.")

            # ── 2차 팝업 처리 (발행 전) ──
            time.sleep(1.5)
            for _ in range(5):
                dismiss_popups(page)
                time.sleep(0.4)
            try:
                page.keyboard.press("Escape")
                time.sleep(0.3)
            except: pass

            # ── 발행 버튼 ──
            set_status("running", "발행 버튼 클릭 중...")
            if not click_publish_btn(page):
                raise RuntimeError("발행 버튼을 찾지 못했습니다.")

            time.sleep(1.5)

            # ── 예약 설정 ──
            if sched:
                set_status("running", f"예약 설정 중... ({sched})")
                set_schedule(page, sched)
                time.sleep(1)

            # ── 최종 발행 확인 ──
            set_status("running", "최종 발행 처리 중...")
            confirm_publish(page)
            time.sleep(3)

            if sched:
                set_status("done", f"예약 발행 완료! ({sched[:10]} {sched[11:16]})")
            else:
                set_status("done", "발행 완료!")

            time.sleep(5)

        finally:
            browser.close()


def do_publish(data):
    """단일 발행"""
    try:
        run_playwright(data, set_st)
    except Exception as e:
        import traceback; traceback.print_exc()
        set_st("error", f"오류: {str(e)}")


def do_batch(items):
    """일괄 발행 — 순서대로 순차 처리"""
    batch_status.update({
        'state':   'running',
        'total':   len(items),
        'current': 0,
        'items':   [{'title': it.get('title', f'항목{i+1}')[:30],
                     'state': 'pending', 'msg': '대기 중'}
                    for i, it in enumerate(items)]
    })

    for i, item in enumerate(items):
        batch_status['current'] = i + 1
        batch_status['items'][i]['state'] = 'running'

        def make_cb(idx):
            def cb(state, msg):
                batch_status['items'][idx]['msg'] = msg
                print(f"[BATCH {idx+1}/{batch_status['total']}] {msg}")
            return cb

        try:
            run_playwright(item, make_cb(i))
            batch_status['items'][i]['state'] = 'done'
            sched = item.get('schedule_dt')
            batch_status['items'][i]['msg'] = (
                f"예약 완료 ({sched[:10]} {sched[11:16]})" if sched else "발행 완료 ✓"
            )
        except Exception as e:
            import traceback; traceback.print_exc()
            batch_status['items'][i]['state'] = 'error'
            batch_status['items'][i]['msg']   = str(e)[:60]

        if i < len(items) - 1:
            time.sleep(3)   # 항목 간 잠시 대기

    batch_status['state'] = 'done'


# ─────────────────────────────────────────────
#  서버 시작
# ─────────────────────────────────────────────

if __name__ == '__main__':
    print("=" * 55)
    print("  네이버 블로그 자동발행 서버 v6.0")
    print("  주소: http://localhost:7777")
    print("  종료: Ctrl + C")
    print("=" * 55)
    app.run(host='127.0.0.1', port=7777, debug=False)
