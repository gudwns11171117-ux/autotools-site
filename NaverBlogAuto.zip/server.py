# -*- coding: utf-8 -*-
import os, sys
os.chdir(os.path.dirname(os.path.abspath(__file__)))
with open("네이버발행서버.py", encoding="utf-8") as src:
    exec(src.read())
