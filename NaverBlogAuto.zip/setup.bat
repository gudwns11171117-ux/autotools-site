@echo off
chcp 65001
title NaverBlog Setup
echo.
echo  ===================================================
echo   Naver Blog Auto Publisher - Setup
echo  ===================================================
echo.
py --version > /dev/null 2>&1
if errorlevel 1 (
    echo  Python not found. Opening download page...
    echo  Install with "Add Python to PATH" checked!
    start https://www.python.org/downloads/
    pause
    exit /b 1
)
echo  [1/3] Python OK
py --version
echo.
echo  [2/3] Installing packages...
py -m pip install --upgrade pip -q
py -m pip install flask flask-cors playwright pyperclip -q
echo  Done!
echo.
echo  [3/3] Installing Chromium (1-3 min)...
py -m playwright install chromium
echo  Done!
echo.
echo  ===================================================
echo   Setup complete! Run: run.bat
echo  ===================================================
pause
