@echo off
title NaverBlog - Install
echo.
echo  ====================================
echo   NaverBlog Auto Publisher - Install
echo  ====================================
echo.

:: Python 
set PY=
py --version >nul 2>&1
if not errorlevel 1 set PY=py
if "%PY%"=="" (
  python --version >nul 2>&1
  if not errorlevel 1 set PY=python
)

:: Python      
if "%PY%"=="" (
  if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe
  )
)

::     
if "%PY%"=="" (
  echo [!] Python not found. Downloading automatically...
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\py_setup.exe'"
  echo [*] Installing Python...
  "%TEMP%\py_setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1
  del "%TEMP%\py_setup.exe"
  ::      (  PATH   )
  set PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe
  :: PATH  
  set PATH=%LOCALAPPDATA%\Programs\Python\Python311;%LOCALAPPDATA%\Programs\Python\Python311\Scripts;%PATH%
  echo [OK] Python installed!
)

echo [1/3] Python OK
echo.
echo [2/3] Installing packages...
"%PY%" -m pip install --upgrade pip --quiet
"%PY%" -m pip install flask flask-cors playwright pyperclip requests --quiet
echo [OK] Packages installed!
echo.
echo [3/3] Installing Playwright browser (1~3 min)...
"%PY%" -m playwright install chromium
echo [OK] Browser installed!
echo.
echo  Done! Run run.bat to start.
echo.
pause
