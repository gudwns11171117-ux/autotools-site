@echo off
setlocal EnableDelayedExpansion
title NaverBlog - Install
echo.
echo  ====================================
echo   NaverBlog Auto Publisher - Install
echo  ====================================
echo.

:: ============================================
::  Find Python
:: ============================================
set "PY="

py -3 --version >nul 2>&1
if not errorlevel 1 set "PY=py -3"

if not defined PY (
  python --version >nul 2>&1
  if not errorlevel 1 set "PY=python"
)

if not defined PY (
  for %%V in (313 312 311 310 39) do (
    if not defined PY (
      if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
        set "PY=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
      )
    )
  )
)

:: Auto-download Python if not found
if not defined PY (
  echo [!] Python not found. Downloading installer...
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\py_setup.exe'"
  if errorlevel 1 (
    echo [ERROR] Download failed. Check your internet connection.
    pause
    exit /b 1
  )
  echo [*] Installing Python 3.11...
  "%TEMP%\py_setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1
  del "%TEMP%\py_setup.exe" >nul 2>&1
  set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
  if not exist "!PY!" (
    echo [ERROR] Python install failed. Please install manually from python.org
    pause
    exit /b 1
  )
  echo [OK] Python installed.
)

echo [1/3] Python OK  ^(%PY%^)
echo.
echo [2/3] Installing required packages...
%PY% -m pip install --upgrade pip
%PY% -m pip install flask flask-cors playwright pyperclip requests
if errorlevel 1 (
  echo.
  echo [ERROR] Package install failed. Check firewall/proxy.
  pause
  exit /b 1
)
echo [OK] Packages installed.
echo.
echo [3/3] Installing Playwright browser ^(1-3 min^)...
%PY% -m playwright install chromium
if errorlevel 1 (
  echo.
  echo [WARN] Playwright browser install may have failed.
  echo        It will auto-retry on first publish.
)

:: Final verification
%PY% -c "import flask, flask_cors, playwright, pyperclip, requests" >nul 2>&1
if errorlevel 1 (
  echo.
  echo [ERROR] Verification failed. Try running as Administrator.
  pause
  exit /b 1
)

echo.
echo  ====================================
echo   Done! Run run.bat to start.
echo  ====================================
echo.
pause
endlocal
