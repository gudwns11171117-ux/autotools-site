@echo off
setlocal EnableDelayedExpansion
title NaverBlog - Install
chcp 65001 >nul 2>&1
echo.
echo  ====================================
echo   NaverBlog Auto Publisher - Install
echo  ====================================
echo.

:: ════════════════════════════════════════════
::  Python 탐색
:: ════════════════════════════════════════════
set "PY="

py -3 --version >nul 2>&1
if not errorlevel 1 set "PY=py -3"

if not defined PY (
  python --version >nul 2>&1
  if not errorlevel 1 set "PY=python"
)

if not defined PY (
  for %%V in (313 312 311 310 39) do (
    if not defined PY (
      if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
        set "PY=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
      )
    )
  )
)

:: Python 미발견 → 자동 다운로드/설치
if not defined PY (
  echo [!] Python이 설치되어 있지 않습니다. 자동 다운로드 중...
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\py_setup.exe'"
  if errorlevel 1 (
    echo [ERROR] Python 다운로드 실패. 인터넷 연결을 확인해 주세요.
    pause
    exit /b 1
  )
  echo [*] Python 설치 중...
  "%TEMP%\py_setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1
  del "%TEMP%\py_setup.exe" >nul 2>&1
  set "PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
  if not exist "!PY!" (
    echo [ERROR] Python 설치에 실패했습니다. python.org에서 수동 설치해 주세요.
    pause
    exit /b 1
  )
  echo [OK] Python 설치 완료!
)

echo [1/3] Python OK  ^(%PY%^)
echo.
echo [2/3] 필수 패키지 설치 중...
%PY% -m pip install --upgrade pip
%PY% -m pip install flask flask-cors playwright pyperclip requests
if errorlevel 1 (
  echo.
  echo [ERROR] 패키지 설치 실패. 방화벽/프록시를 확인해 주세요.
  pause
  exit /b 1
)
echo [OK] 패키지 설치 완료!
echo.
echo [3/3] Playwright 브라우저 설치 중 (1~3분)...
%PY% -m playwright install chromium
if errorlevel 1 (
  echo.
  echo [WARN] Playwright 브라우저 설치에 실패했을 수 있습니다.
  echo         첫 발행 시 자동 재시도됩니다.
)

:: 최종 검증
%PY% -c "import flask, flask_cors, playwright, pyperclip, requests" >nul 2>&1
if errorlevel 1 (
  echo.
  echo [ERROR] 설치 검증 실패. 관리자 권한으로 다시 실행해 주세요.
  pause
  exit /b 1
)

echo.
echo  ====================================
echo   설치 완료! run.bat 을 실행하세요.
echo  ====================================
echo.
pause
endlocal
